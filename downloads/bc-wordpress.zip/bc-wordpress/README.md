# The BrainControl WordPress Theme

Please visit [BrainControl.me](http://braincontrol.me) for more information on the Bitcoin Wallet technicalities.

This theme is in a very early beta state, and allows you to use it at a standalone (fullscreen) Bitcoin Wallet (by default), whilst also allowing you
to utilize the same marketing site as seen on our homepage. You can even replace the BrainControl application with your own Application using iFrames.
