<div id="mb_modal_mailchimp" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header" style="min-height: 50px;">
				<button class="close" aria-hidden="true" data-dismiss="modal" type="button">x</button>
				<h4 id="mb_modal_mailchimp_label" style="right: 40px; position:absolute; left:20px; top:0; line-height: 30px;"></h4>
			</div>
			<div class="modal-body">

			<!-- Begin MailChimp Signup Form -->

			<div id="mc_embed_signup">
			<form action="http://braincontrol.us3.list-manage.com/subscribe/post?u=b895175e50952d066a803be4c&amp;id=05a1cccca8" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate form-fluid" target="_blank" novalidate>
				<input type="email" value="" name="EMAIL" class="email form-control" id="mce-EMAIL" placeholder="email address" required>
				<!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
				<div style="position: absolute; left: -5000px;"><input type="text" name="b_b895175e50952d066a803be4c_05a1cccca8" value=""></div>
				<div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="btn btn-info pull-right" style="margin: 10px 0 0;"></div>
				<div class="clearfix"></div>
			</form>
			</div>

			<!--End mc_embed_signup-->

			</div>
		</div>
	</div>
</div>