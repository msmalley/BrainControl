## TODO:

#### BEFORE LAUNCH

* WordPress Theme
* Website
* GitHub Ready
* CV / Smalley.my
* Blog Post (Full Story)
* Documentation / Blog Post (Mention TOR in Docs but No LocalStorage means Only Good for Single Wallets with Little Use and (or) Paper Wallet Generation)

-- Need MicroSD!!!

* Tested FirefoxOS Photos / QR Scan?
* FirefoxOS Wrapper


#### THE LAUNCH SEQUENCE

* Facebook / Twitter to BrainControl.me
* Apply at Mozilla, Automattic, BitPay and Coinbase
* Set-Up AngelList - Apply at WebFWD, BitAngels, BTC Foundation Grant
* Consider Crowd-Funding ...? (Pozible and Backer)
* Investors such as SeedCoin and JFDI (Hardware)
* Write Will Work for Coin Post (if no one has replied) �?


#### AFTER LAUNCH / WITH FUNDING OR SUPPORT

* WordPress Plugin
* Improve Calculator
* Separate and Improve Upon Underlying HTML / CSS / JS Framework for Mobile Apps
* 2 Factor Authentication - Added Saltiness for Key Creation
* Optional Device Wide (Startup) Password Protection
* Options for 3rd Party Email Integration (for PW resets)
* How to edit accounts and contacts?
* Merged wallets?
* Allow import of keys to be absorbed into existing wallet?
* Better Polling / Notifications of Incoming Payments
* Scan QR Code (added to settings menu)
* Random salt functionality (for those that want printed backups of keys)
* Start and (or) improve upon documentation
* Additional Fiat-Currencies
* Ability to Use BlockChain.info Alternatives
* Ability to Create Payment Requests
* Ability to Generate Coupons
* Additional UIX Languages

Mark Smalley
http://localhost/labs/braincontrol/mobile.html