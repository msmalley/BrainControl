# The BrainControl FirefoxOS Application

Please visit [BrainControl.me](http://braincontrol.me) for more information on the Bitcoin Wallet technicalities.

* Tested on Firefox 1.0+
* Tried Testing on Firefox 1.2+ but broke my device along the (upgrading) way :-(

